const json = (data, status=200) => new Response(JSON.stringify(data), {
  status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" }
});
const now = () => new Date().toISOString();
const dayKey = () => new Date().toISOString().slice(0,10);
const uid = () => crypto.randomUUID();
const enc = new TextEncoder();

async function sha256(s) {
  const b = await crypto.subtle.digest("SHA-256", enc.encode(s));
  return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");
}
async function passwordHash(password, salt) {
  const material = await crypto.subtle.importKey("raw", enc.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({name:"PBKDF2", salt:enc.encode(salt), iterations:210000, hash:"SHA-256"}, material, 256);
  return [...new Uint8Array(bits)].map(x=>x.toString(16).padStart(2,"0")).join("");
}
function cookieToken(req) {
  const raw = req.headers.get("Cookie") || "";
  const m = raw.match(/(?:^|; )kas_session=([^;]+)/);
  return m ? decodeURIComponent(m[1]) : "";
}
async function auth(req, env) {
  const token = cookieToken(req);
  if (!token) return null;
  const hash = await sha256(token);
  return await env.DB.prepare(
    "SELECT u.id,u.email,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>?"
  ).bind(hash, now()).first();
}
function sessionCookie(token, maxAge=60*60*24*14) {
  return `kas_session=${encodeURIComponent(token)}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${maxAge}`;
}
async function requireUser(req, env) {
  const user = await auth(req, env);
  return user || null;
}
async function saveGeneration(env, user, kind, prompt, status, objectKey=null, mimeType=null, error=null) {
  const id = uid();
  await env.DB.prepare("INSERT INTO generations(id,user_id,kind,prompt,status,object_key,mime_type,error,created_at) VALUES(?,?,?,?,?,?,?,?,?)")
    .bind(id,user.id,kind,prompt,status,objectKey,mimeType,error,now()).run();
  return id;
}
async function handleGenerate(req, env, user, kind) {
  const form = await req.formData();
  const prompt = String(form.get("prompt") || "").trim().slice(0,3000);
  if (!prompt) return json({error:"Enter a prompt first."},400);
  const uploaded = form.get("image");
  if ((kind === "image-to-video") && (!uploaded || typeof uploaded.arrayBuffer !== "function"))
    return json({error:"Upload an image for image-to-video."},400);
  const genId = await saveGeneration(env,user,kind,prompt,"processing");
  try {
    let result;
    if (kind === "text-to-image") {
      const output = await env.AI.run(env.IMAGE_MODEL || "@cf/black-forest-labs/flux-1-schnell", { prompt });
      let bytes, mime = "image/png";
      if (output instanceof ReadableStream) {
        bytes = await new Response(output).arrayBuffer();
      } else if (output?.image) {
        const bin = atob(output.image);
        bytes = Uint8Array.from(bin, c=>c.charCodeAt(0)).buffer;
      } else {
        throw new Error("Image model returned an unsupported response.");
      }
      const key = `users/${user.id}/${genId}.png`;
      await env.MEDIA.put(key, bytes, { httpMetadata: { contentType:mime } });
      await env.DB.prepare("UPDATE generations SET status='complete',object_key=?,mime_type=? WHERE id=?")
        .bind(key,mime,genId).run();
      result = {id:genId,kind,status:"complete",url:`/api/media/${genId}`};
    } else {
      // Video providers are not included as a fake demo. Configure a real provider endpoint
      // and secret only if you have an actually free, authorized inference service.
      const endpoint = env.VIDEO_PROVIDER_URL;
      const key = env.VIDEO_PROVIDER_KEY;
      if (!endpoint || !key) throw new Error("Video generation is not configured. A real video inference provider URL and API key are required; Cloudflare hosting alone does not generate video for free.");
      const body = new FormData();
      body.set("prompt",prompt);
      body.set("mode",kind);
      if (uploaded && typeof uploaded.arrayBuffer === "function") body.set("image",uploaded,uploaded.name || "input-image");
      const response = await fetch(endpoint,{method:"POST",headers:{"Authorization":`Bearer ${key}`},body});
      if (!response.ok) throw new Error(`Video provider returned HTTP ${response.status}.`);
      const data = await response.json();
      if (!data.url) throw new Error("Video provider must return a public result URL in JSON field 'url'.");
      await env.DB.prepare("UPDATE generations SET status='complete',object_key=?,mime_type='video/mp4' WHERE id=?")
        .bind(data.url,genId).run();
      result = {id:genId,kind,status:"complete",url:data.url};
    }
    return json({generation:result});
  } catch(e) {
    await env.DB.prepare("UPDATE generations SET status='failed',error=? WHERE id=?").bind(String(e.message || e).slice(0,500),genId).run();
    return json({error:String(e.message || e)},503);
  }
}
async function router(req, env) {
  const url = new URL(req.url), path = url.pathname, method = req.method;
  if (path === "/api/health") return json({ok:true,app:env.APP_NAME || "Kattel AI Studio"});
  if (path === "/api/register" && method==="POST") {
    const b = await req.json().catch(()=>({}));
    const email = String(b.email||"").trim().toLowerCase();
    const password = String(b.password||"");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || password.length < 10)
      return json({error:"Enter a valid email and a password with at least 10 characters."},400);
    const salt = crypto.randomUUID(), hash = await passwordHash(password,salt), id=uid();
    try {
      await env.DB.prepare("INSERT INTO users(id,email,password_hash,salt,role,created_at) VALUES(?,?,?,?,?,?)")
        .bind(id,email,hash,salt,email===(env.ADMIN_EMAIL||"").toLowerCase()?"admin":"user",now()).run();
    } catch { return json({error:"That email may already have an account."},409); }
    const token = crypto.randomUUID()+crypto.randomUUID();
    await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)")
      .bind(await sha256(token),id,new Date(Date.now()+14*864e5).toISOString()).run();
    return new Response(JSON.stringify({user:{id,email,role:email===(env.ADMIN_EMAIL||"").toLowerCase()?"admin":"user"}}),{headers:{"content-type":"application/json","set-cookie":sessionCookie(token)}});
  }
  if (path === "/api/login" && method==="POST") {
    const b=await req.json().catch(()=>({})), email=String(b.email||"").trim().toLowerCase();
    const row=await env.DB.prepare("SELECT * FROM users WHERE email=?").bind(email).first();
    if (!row || await passwordHash(String(b.password||""),row.salt)!==row.password_hash) return json({error:"Email or password is incorrect."},401);
    const token=crypto.randomUUID()+crypto.randomUUID();
    await env.DB.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,?)")
      .bind(await sha256(token),row.id,new Date(Date.now()+14*864e5).toISOString()).run();
    return new Response(JSON.stringify({user:{id:row.id,email:row.email,role:row.role}}),{headers:{"content-type":"application/json","set-cookie":sessionCookie(token)}});
  }
  if (path === "/api/logout" && method==="POST") {
    const token=cookieToken(req); if(token) await env.DB.prepare("DELETE FROM sessions WHERE token_hash=?").bind(await sha256(token)).run();
    return new Response(JSON.stringify({ok:true}),{headers:{"content-type":"application/json","set-cookie: kas_session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0"}});
  }
  const user=await requireUser(req,env);
  if (path.startsWith("/api/") && !user) return json({error:"Please sign in."},401);
  if (path === "/api/me") return json({user});
  if (path === "/api/history") {
    const rows=await env.DB.prepare("SELECT id,kind,prompt,status,object_key,mime_type,error,created_at FROM generations WHERE user_id=? ORDER BY created_at DESC LIMIT 100").bind(user.id).all();
    return json({items:(rows.results||[]).map(r=>({...r,url:r.status==="complete"?(r.object_key?.startsWith("http")?r.object_key:`/api/media/${r.id}`):null}))});
  }
  if (path === "/api/generate/image" && method==="POST") return handleGenerate(req,env,user,"text-to-image");
  if (path === "/api/generate/text-video" && method==="POST") return handleGenerate(req,env,user,"text-to-video");
  if (path === "/api/generate/image-video" && method==="POST") return handleGenerate(req,env,user,"image-to-video");
  if (path.startsWith("/api/media/") && method==="GET") {
    const id=path.split("/").pop();
    const row=await env.DB.prepare("SELECT object_key,mime_type FROM generations WHERE id=? AND user_id=? AND status='complete'").bind(id,user.id).first();
    if(!row || !row.object_key) return json({error:"Media not found."},404);
    if(row.object_key.startsWith("http")) return Response.redirect(row.object_key,302);
    const obj=await env.MEDIA.get(row.object_key);
    if(!obj) return json({error:"Media file missing."},404);
    return new Response(obj.body,{headers:{"content-type":row.mime_type||"application/octet-stream","cache-control":"private, max-age=3600"}});
  }
  if (path === "/api/admin/overview") {
    if(user.role!=="admin") return json({error:"Admin only."},403);
    const [users,gens]=await Promise.all([
      env.DB.prepare("SELECT COUNT(*) AS n FROM users").first(),
      env.DB.prepare("SELECT COUNT(*) AS n FROM generations").first()
    ]);
    return json({users:users.n,generations:gens.n});
  }
  if (path === "/api/admin/users") {
    if(user.role!=="admin") return json({error:"Admin only."},403);
    const rows=await env.DB.prepare("SELECT id,email,role,created_at FROM users ORDER BY created_at DESC LIMIT 200").all();
    return json({users:rows.results});
  }
  return json({error:"Not found."},404);
}
export default {
  async fetch(req,env,ctx) {
    const url=new URL(req.url);
    if(url.pathname.startsWith("/api/")) {
      try { return await router(req,env); }
      catch(e) { return json({error:"Server error: "+String(e.message||e)},500); }
    }
    return env.ASSETS.fetch(req);
  }
};
