# Kattel AI Studio — No-Credit Edition

A Cloudflare Workers application source package with:
- Email/password registration and login
- User dashboard
- Generation history
- Admin overview
- Cloudflare D1 database
- Cloudflare R2 media storage
- Cloudflare Workers AI text-to-image integration
- Text-to-video and image-to-video provider adapter
- Mobile-responsive interface
- **No in-app credit system, no credit counter, and no daily app-level generation allowance**

## Hosting limits and realistic daily capacity

The app intentionally has **no user credit balance, no credit deductions, and no app-level daily generation allowance**. A notice pop-up explains that provider capacity can still pause generation.

On Cloudflare's currently published free allowances (check the live dashboard because terms can change):
- Workers AI: **10,000 Neurons per day**. This is a compute allowance, not a count of images. The number of images depends on the selected model and its neuron usage per generation.
- Workers Free: **100,000 incoming Worker requests per day**. These are website/API requests, not 100,000 image generations.

There is no reliable fixed daily image or video count to promise from these figures alone. Text-to-video and image-to-video also depend on the separate video provider's plan, limits, and capacity. Check usage in your Cloudflare dashboard before inviting many users. The app does not automatically guarantee or enforce a daily count.

Official references:
- https://developers.cloudflare.com/workers-ai/platform/pricing/
- https://developers.cloudflare.com/workers/platform/limits/

## Important: no credits does not mean infinite computing

The app does not display, deduct, or enforce user credits. Users are not shown a credit balance or told they have a certain number of credits.

However, no hosting provider offers unlimited AI video/image computation for free. Cloudflare, the model provider, and any connected video provider still have infrastructure quotas, concurrency limits, model availability rules, and service terms. When a provider's free allowance is exhausted or unavailable, generation may fail until service becomes available again. The app cannot bypass those provider limits or create thousands of free GPU jobs without compute resources.

## Included generation functionality

### Text-to-image
Connected to Cloudflare Workers AI using the configured model `@cf/black-forest-labs/flux-1-schnell`. It requires the Workers AI binding and model availability in your Cloudflare account. Model usage may be subject to Cloudflare's current plan and pricing.

### Text-to-video and image-to-video
The routes and UI are included, but a real video inference provider must be configured. Cloudflare hosting alone does not provide free unlimited video generation. Configure a provider only after verifying that it genuinely offers free usage and permits your intended use.

The provider must accept `POST multipart/form-data`:
- `prompt`: text prompt
- `mode`: `text-to-video` or `image-to-video`
- `image`: optional uploaded image

It must return JSON:
```json
{"url":"https://provider.example/result.mp4"}
```

Set secrets using Wrangler:
```bash
npx wrangler secret put VIDEO_PROVIDER_URL
npx wrangler secret put VIDEO_PROVIDER_KEY
```
Never put API keys in frontend JavaScript.

## Deploy from Android Chrome (Desktop site)

This project requires a terminal that supports Node.js, Git and Wrangler. Cloudflare's dashboard by itself does not run the full deployment commands. If you only have an Android phone, use a browser-based development environment with a terminal.

1. Sign in at https://dash.cloudflare.com/
2. Create a D1 database named `kattel-ai-studio-db`.
3. Create an R2 bucket named `kattel-ai-studio-media`.
4. Upload this ZIP's contents to a GitHub repository, or open them in a browser-based coding environment.
5. Install dependencies:
```bash
npm install
```
6. Create D1 if you have not already:
```bash
npx wrangler d1 create kattel-ai-studio-db
```
Copy the returned database ID into `wrangler.toml`, replacing `REPLACE_WITH_D1_DATABASE_ID`.
7. Create the R2 bucket if needed:
```bash
npx wrangler r2 bucket create kattel-ai-studio-media
```
8. Apply the database schema:
```bash
npx wrangler d1 migrations apply DB --remote
```
9. Set your admin email:
```bash
npx wrangler secret put ADMIN_EMAIL
```
Enter the email you will use for the first account. Register with that email to receive the admin role.
10. Deploy:
```bash
npx wrangler deploy
```

## Production requirements
Before inviting the public, add email verification, moderation, abuse prevention, privacy policy, terms, logging and monitoring. These protections are not user-facing credits; they protect the service and prevent abuse. Keep secrets private and use a strong admin password.

## Branding
Suggested public message: **“Free AI image and video creation for everyone.”**
Do not advertise unlimited generation unless your actual inference provider contract and compute capacity guarantee it. This source package removes the app's credit system, but cannot guarantee unlimited free compute.


## Android APK preparation (PWA)

This package now includes a web app manifest, 192px and 512px icons, and a service worker. After deploying the app to a public HTTPS URL, open https://www.pwabuilder.com/ in Chrome, enter that URL, and use its Android package flow. A public HTTPS deployment is required before creating an APK. This package is PWA-ready; it is not itself an APK, and the backend still needs to be deployed/configured for login and AI generation to work.
